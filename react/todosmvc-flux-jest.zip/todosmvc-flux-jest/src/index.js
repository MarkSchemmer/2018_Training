import React from 'react';
import ReactDom from 'react-dom';


class App extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            search:'',
            options:[]
        }
        this.findSuggestions = this.findSuggestions.bind(this)
    }

    findSuggestions(whatToSearch){
        getSuggestions(whatToSearch).then(res => {
            this.setState({ options : res })
        })
    }

    getSuggest(whatToSearch){
        efficecntUpdate(this.findSuggestions, whatToSearch)
    }

    change(e){
        this.setState({
            search:e.target.value
        }, () => this.getSuggest(this.state.search))
    }

    render(){

        const { options, search } = this.state;

        const listStyle = {
            listStyleType:'none'
        }

        const prepareSearch = (suggestion) => {
            const [mySearch, mock, number] = suggestion.split('_');
            const spanStyle = {
                opacity:'0.5'
            }
                return (
                    <li>
                        <span style={spanStyle}>{mySearch}</span><strong>{mock + "" +  number}</strong>
                    </li>
                );
        }

        const output = options.map(suggestion => prepareSearch(suggestion));
        
        

        return (
                <div>
                    Search : <input 
                                    onChange={(e) => this.change(e)}
                                    value={search} />
                    <ul style={listStyle}>
                        {search.length>0?output:null}
                    </ul>
                </div>
        );
    }
}



// This function mocks the asynchronous API to fetch the suggestions by prefix.
// Example:
//  getSuggestions('fake').then(function(val) {
//     console.log(val);
//  })
function getSuggestions(prefix) {
    const result = Array
      .from(new Array(10), function(x, i) {
        return i;
      })
      .map(function(x) {
        return prefix + '_mock_' + x;
      });
    const delay = Math.random() * 800 + 200; // delay 200~1000ms
    return new Promise(function(resolve, reject) {
      setTimeout(resolve, delay, result);
    });
  }


  function debounce(func, wait, immediate) {
	var timeout;
	return function() {
		var context = this, args = arguments;
		var later = function() {
			timeout = null;
			if (!immediate) func.apply(context, args);
		};
		var callNow = immediate && !timeout;
		clearTimeout(timeout);
		timeout = setTimeout(later, wait);
		if (callNow) func.apply(context, args);
	};
};
  
var efficecntUpdate = debounce(function(fn, say){
    fn(say)
}, 250)

ReactDom.render(<App />, document.getElementById('root'))